PAPPERSKORGAR MALMO - PUBLICERINGSPAKET

Innehall
- index.html: Leaflet-karta med 4 053 inbaddade papperskorgar.

Krav
- Webbserver med HTTPS.
- Internetatkomst till:
  https://unpkg.com
  https://*.tile.openstreetmap.org
  https://www.google.com
  https://www.openstreetmap.org
- Webblasaren maste fa anvanda platstjanster om knappen Min position ska fungera.

Rekommenderad publicering
1. Azure Static Web Apps eller en intern IIS/Nginx-webbserver.
2. Publicera index.html i webbrotens katalog.
3. Oppna webbadressen pa dator och mobil.
4. Kontrollera sokning, filter, popup, Navigera och Min position.

SharePoint
Ett vanligt SharePoint-dokumentbibliotek laddar ofta ner HTML-filer i stallet for att kora dem. Anvand darfor helst en riktig webbserver eller Azure Static Web Apps. Om Malmo stad har en intern webbplattform kan IT publicera index.html dar.

Sakerhet och drift
- Kartan innehaller inga inloggningsuppgifter eller API-nycklar.
- Papperskorgsdatan ar inbaddad i index.html och uppdateras inte automatiskt.
- Vid ny GIS-export maste filen byggas om och publiceras pa nytt.
- OpenStreetMap-standardplattor ar avsedda for normal anvandning. Vid stor intern anvandning bor IT/GIS valja en godkand kartplatteleverantor eller egen cache.
